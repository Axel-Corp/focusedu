// Ce script pourrait être injecté sur les pages bloquées pour afficher un message.
document.body.innerHTML = '<h1>Accès interdit</h1><p>Ce site est bloqué pour vous aider à rester concentré sur vos études.</p>';
